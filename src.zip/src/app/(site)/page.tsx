import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";

import { FaqAccordion } from "@/components/home/FaqAccordion";
import { CONTACTS } from "@/data/contacts";
import { getPublishedPortfolioProjects } from "@/lib/portfolio-db";
import {
  SITE_DESCRIPTION,
  SITE_NAME,
  SITE_URL,
} from "@/lib/site";

import styles from "./page.module.css";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: {
    absolute: "4HOME — меблі на замовлення у Києві",
  },

  description: SITE_DESCRIPTION,

  alternates: {
    canonical: "/",
  },

  openGraph: {
    type: "website",
    url: "/",
    locale: "uk_UA",
    siteName: SITE_NAME,
    title: "4HOME — меблі на замовлення у Києві",
    description: SITE_DESCRIPTION,
  },

  twitter: {
    card: "summary_large_image",
    title: "4HOME — меблі на замовлення у Києві",
    description: SITE_DESCRIPTION,
  },
};
const advantages = [
  {
    number: "01",
    title: "За вашими розмірами",
    description:
      "Меблі проєктуються під конкретне приміщення, планування та ваші побажання.",
  },
  {
    number: "02",
    title: "Прорахунок до виготовлення",
    description:
      "До початку робіт погоджуємо конструкцію, матеріали та вартість проєкту.",
  },
  {
    number: "03",
    title: "Від проєкту до монтажу",
    description:
      "Один зрозумілий процес: проєктування, виготовлення, доставка та встановлення.",
  },
  {
    number: "04",
    title: "Реальні виконані роботи",
    description:
      "Показуємо виконані проєкти, щоб ви могли оцінити стиль, підхід і результат.",
  },
];

const categories = [
  {
    number: "01",
    title: "Кухні",
    description:
      "Кухні за індивідуальними розмірами з урахуванням планування, техніки та ваших щоденних сценаріїв.",
    href: "/kitchens",
    image: "/images/portfolio/kitchen-luxury/luxury_kitchen_7.webp",
    alt: "Кухня на замовлення",
    layout: "primary",
  },
  {
    number: "02",
    title: "Розпашні шафи",
    description:
      "Шафи для спальні, передпокою, дитячої та інших приміщень.",
    href: "/wardrobes#hinged",
    image: "/images/home/categories/hinged-wardrobes.webp",
    alt: "Розпашна шафа на замовлення",
    layout: "secondary",
  },
  {
    number: "03",
    title: "Шафи-купе",
    description:
      "Вбудовані та окремостоячі рішення для ефективного використання простору.",
    href: "/wardrobes#sliding",
    image: "/images/home/categories/sliding-wardrobes.webp",
    alt: "Шафа-купе на замовлення",
    layout: "tertiary",
  },
  {
    number: "04",
    title: "Інші меблі",
    description:
      "Тумби, столи, консолі та інші корпусні меблі, створені під ваш простір.",
    href: "/furniture",
    image: "/images/portfolio/media-console/media_console_2.webp",
    alt: "Корпусні меблі на замовлення",
    layout: "minor",
  },
];

const processSteps = [
  {
    number: "01",
    title: "Запит",
    description:
      "Надсилаєте фото, розміри або коротко описуєте, які меблі вам потрібні.",
  },
  {
    number: "02",
    title: "Замір",
    description:
      "Уточнюємо розміри приміщення та важливі технічні особливості майбутнього проєкту.",
  },
  {
    number: "03",
    title: "Прорахунок",
    description:
      "Формуємо конструкцію, підбираємо матеріали та розраховуємо вартість.",
  },
  {
    number: "04",
    title: "Погодження",
    description:
      "Узгоджуємо остаточний вигляд, наповнення, матеріали та деталі замовлення.",
  },
  {
    number: "05",
    title: "Виготовлення",
    description:
      "Після погодження проєкт переходить у виготовлення за затвердженими параметрами.",
  },
  {
    number: "06",
    title: "Доставка та монтаж",
    description:
      "Доставляємо меблі, виконуємо встановлення та перевіряємо готовий результат.",
  },
];

const materials = [
  {
    number: "01",
    title: "Корпусні матеріали",
    description:
      "Підбираємо матеріали для корпусу з урахуванням призначення меблів, навантаження та бюджету.",
  },
  {
    number: "02",
    title: "Фасади",
    description:
      "Підбираємо колір, фактуру та тип фасадів так, щоб меблі гармонійно вписувалися в інтер’єр.",
  },
  {
    number: "03",
    title: "Стільниці та поверхні",
    description:
      "Враховуємо зовнішній вигляд, практичність і умови використання робочих поверхонь.",
  },
  {
    number: "04",
    title: "Фурнітура та механізми",
    description:
      "Підбираємо петлі, напрямні, системи відкривання та інші механізми відповідно до конструкції.",
  },
];

const aboutFacts = [
  { number: "01", title: "Індивідуальні розміри" },
  { number: "02", title: "Погодження до виготовлення" },
  { number: "03", title: "Доставка та встановлення" },
  { number: "04", title: "Київ та передмістя" },
];

const faqItems = [
  {
    question: "Скільки коштують меблі на замовлення?",
    answer:
      "Вартість залежить від розмірів, конструкції, матеріалів, фурнітури та складності проєкту. Точний прорахунок можна зробити після уточнення основних параметрів.",
  },
  {
    question: "Чи можна зробити попередній прорахунок за фото та розмірами?",
    answer:
      "Так. Для попереднього прорахунку можна надіслати фото приміщення, приблизні розміри та опис того, які меблі потрібні.",
  },
  {
    question: "Чи виїжджаєте на замір?",
    answer:
      "Так. Для точного проєктування уточнюємо розміри приміщення та технічні особливості, які можуть впливати на конструкцію меблів.",
  },
  {
    question: "Чи можна обрати матеріали та фурнітуру?",
    answer:
      "Так. Матеріали, фасади, кольори, стільниці та механізми підбираються відповідно до конструкції, стилю, умов використання та бюджету.",
  },
  {
    question: "Чи займаєтесь доставкою та монтажем?",
    answer:
      "Так. Після виготовлення меблі доставляються та встановлюються на об’єкті.",
  },
  {
    question: "Чи є готові меблі в наявності?",
    answer:
      "Ні. 4HOME працює з індивідуальними замовленнями. Меблі створюються під конкретне приміщення, розміри та побажання замовника.",
  },
];
const websiteJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  "@id": `${SITE_URL}/#website`,
  url: SITE_URL,
  name: SITE_NAME,
  inLanguage: "uk-UA",
  publisher: {
    "@id": `${SITE_URL}/#business`,
  },
};

const organizationJsonLd = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "@id": `${SITE_URL}/#business`,
  name: SITE_NAME,
  url: SITE_URL,
  description: SITE_DESCRIPTION,

  telephone: CONTACTS.primaryPhone.international.replace(/\s/g, ""),
  email: CONTACTS.email.display,

  areaServed: "Київ та передмістя",

  sameAs: [
    CONTACTS.instagram.href,
    CONTACTS.telegram.href,
  ],

  knowsAbout: [
    "Кухні на замовлення",
    "Шафи на замовлення",
    "Шафи-купе",
    "Корпусні меблі",
    "Меблі за індивідуальними розмірами",
  ],
};

const serviceJsonLd = {
  "@context": "https://schema.org",
  "@type": "Service",
  "@id": `${SITE_URL}/#custom-furniture-service`,

  name: "Меблі на замовлення 4HOME",

  description:
    "Проєктування, виготовлення, доставка та встановлення меблів за індивідуальними розмірами у Києві та передмісті.",

  provider: {
    "@id": `${SITE_URL}/#business`,
  },

  areaServed: "Київ та передмістя",

  serviceType: [
    "Кухні на замовлення",
    "Шафи на замовлення",
    "Шафи-купе на замовлення",
    "Корпусні меблі на замовлення",
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqItems.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

export default async function Home() {
  let homePortfolioProjects:
    Awaited<
      ReturnType<
        typeof getPublishedPortfolioProjects
      >
    > = [];

  try {
    homePortfolioProjects = (
      await getPublishedPortfolioProjects()
    ).slice(0, 3);
  } catch (error) {
    console.error(
      "Failed to load homepage portfolio projects:",
      error,
    );
  }
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(
            websiteJsonLd,
          ).replace(/</g, "\\u003c"),
        }}
      />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(
            organizationJsonLd,
          ).replace(/</g, "\\u003c"),
        }}
      />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(
            serviceJsonLd,
          ).replace(/</g, "\\u003c"),
        }}
      />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(
            faqJsonLd,
          ).replace(/</g, "\\u003c"),
        }}
      />

      <main>
        <section className={styles.hero}>
          <div className={`container ${styles.heroInner}`}>
            <div className={styles.heroContent}>
              <p className={styles.eyebrow}>4HOME • КИЇВ</p>

              <h1 className={styles.title}>
                Меблі на замовлення
                <br />
                у Києві
              </h1>

              <p className={styles.description}>
                Проєктуємо, прораховуємо вартість, виготовляємо, доставляємо
                та встановлюємо корпусні меблі за індивідуальними розмірами.
              </p>

              <div className={styles.actions}>
                <Link href="/contacts#lead-form" className={styles.primaryButton}>
                  Розрахувати вартість
                </Link>

                <Link href="/portfolio" className={styles.secondaryButton}>
                  Переглянути роботи
                </Link>
              </div>
            </div>

            <div className={styles.heroVisual}>
              <div className={styles.imageFrame}>
                <Image
                  src="/images/portfolio/kitchen-luxury/luxury_kitchen_7.webp"
                  alt="Кухня на замовлення 4HOME"
                  fill
                  priority
                  fetchPriority="high"
                  sizes="(max-width: 900px) 100vw, (max-width: 1328px) 55vw, 670px"
                  className={styles.heroImage}
                />
              </div>
            </div>
          </div>
        </section>

        <section className={styles.advantages}>
          <div className="container">
            <div className={styles.advantagesHeader}>
              <p className={styles.sectionEyebrow}>ІНДИВІДУАЛЬНИЙ ПІДХІД</p>

              <h2 className={styles.sectionTitle}>
                Меблі, створені
                <br />
                для вашого простору
              </h2>

              <p className={styles.sectionIntro}>
                Не готові рішення зі складу, а меблі, які створюються під
                конкретне приміщення, ваші потреби та майбутній інтер’єр.
              </p>
            </div>

            <div className={styles.advantagesGrid}>
              {advantages.map((item) => (
                <article key={item.number} className={styles.advantageCard}>
                  <span className={styles.advantageNumber}>{item.number}</span>

                  <div className={styles.advantageContent}>
                    <h3 className={styles.advantageTitle}>{item.title}</h3>

                    <p className={styles.advantageDescription}>
                      {item.description}
                    </p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.categories}>
          <div className="container">
            <div className={styles.categoriesHeader}>
              <div>
                <p className={styles.categoriesEyebrow}>ЩО МИ ВИГОТОВЛЯЄМО</p>

                <h2 className={styles.categoriesTitle}>
                  Меблі для різних
                  <br />
                  просторів і задач
                </h2>
              </div>

              <p className={styles.categoriesIntro}>
                Кожен проєкт починається не з готової моделі, а з вашого
                приміщення, розмірів, потреб і побажань до майбутніх меблів.
              </p>
            </div>

            <div className={styles.categoriesGrid}>
              {categories.map((category) => (
                <article
                  key={category.number}
                  className={`${styles.categoryCard} ${
                    styles[
                      `category${category.layout[0].toUpperCase()}${category.layout.slice(
                        1,
                      )}`
                    ]
                  }`}
                >
                  <Link href={category.href} className={styles.categoryLink}>
                    <div className={styles.categoryImageWrapper}>
                      <Image
                        src={category.image}
                        alt={category.alt}
                        fill
                        sizes={
                          category.layout === "primary" ||
                          category.layout === "tertiary"
                            ? "(max-width: 760px) 100vw, (max-width: 1328px) 58vw, 737px"
                            : "(max-width: 760px) 100vw, (max-width: 1328px) 42vw, 519px"
                        }
                        className={styles.categoryImage}
                      />

                      <div className={styles.categoryShade} />

                      <span className={styles.categoryNumber}>
                        {category.number}
                      </span>

                      <span className={styles.categoryArrow} aria-hidden="true">
                        ↗
                      </span>
                    </div>

                    <div className={styles.categoryContent}>
                      <h3 className={styles.categoryTitle}>{category.title}</h3>

                      <p className={styles.categoryDescription}>
                        {category.description}
                      </p>

                      <span className={styles.categoryMore}>
                        Переглянути
                        <span aria-hidden="true">→</span>
                      </span>
                    </div>
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.portfolio}>
          <div className="container">
            <div className={styles.portfolioHeader}>
              <div>
                <p className={styles.portfolioEyebrow}>НАШІ РОБОТИ</p>

                <h2 className={styles.portfolioTitle}>
                  Подивіться на
                  <br />
                  результат наживо
                </h2>
              </div>

              <div>
                <p className={styles.portfolioIntro}>
                  Кілька прикладів виконаних меблів. У повному портфоліо
                  зберемо більше фотографій кожного проєкту.
                </p>

                <Link href="/portfolio" className={styles.portfolioAllLink}>
                  Усі роботи
                  <span aria-hidden="true">→</span>
                </Link>
              </div>
            </div>

            {homePortfolioProjects.length > 0 ? (
              <div className={styles.portfolioGrid}>
                {homePortfolioProjects.map(
                  (project, index) => {
                    const featured =
                      index === 0;

                    return (
                      <article
                        key={project.id}
                        className={
                          featured
                            ? styles.portfolioFeatured
                            : styles.portfolioSmall
                        }
                      >
                        <Link
                          href={`/portfolio/${project.slug}`}
                          scroll={false}
                          className={styles.portfolioLink}
                        >
                          <div className={styles.portfolioImageWrapper}>
                            <Image
                              src={project.coverImage}
                              alt={`${project.title} — 4HOME`}
                              fill
                              sizes={
                                featured
                                  ? "(max-width: 760px) 100vw, (max-width: 1328px) 58vw, 737px"
                                  : "(max-width: 760px) 100vw, (max-width: 1328px) 42vw, 519px"
                              }
                              className={styles.portfolioImage}
                            />

                            <span className={styles.portfolioNumber}>
                              {String(index + 1).padStart(2, "0")}
                            </span>

                            <span
                              className={styles.portfolioArrow}
                              aria-hidden="true"
                            >
                              ↗
                            </span>
                          </div>

                          <div className={styles.portfolioInfo}>
                            <p className={styles.portfolioCategory}>
                              {project.category}
                            </p>

                            <h3 className={styles.portfolioProjectTitle}>
                              {project.title}
                            </h3>
                          </div>
                        </Link>
                      </article>
                    );
                  },
                )}
              </div>
            ) : (
              <div className={styles.portfolioUnavailable}>
                <p>
                  Нові роботи готуємо до публікації.
                </p>

                <Link href="/portfolio">
                  Перейти до портфоліо
                  <span aria-hidden="true">→</span>
                </Link>
              </div>
            )}

            <div className={styles.portfolioMobileAction}>
              <Link href="/portfolio" className={styles.portfolioMobileLink}>
                Переглянути всі роботи
                <span aria-hidden="true">→</span>
              </Link>
            </div>
          </div>
        </section>

        <section className={styles.process}>
          <div className="container">
            <div className={styles.processHeader}>
              <div>
                <p className={styles.processEyebrow}>ЯК МИ ПРАЦЮЄМО</p>

                <h2 className={styles.processTitle}>
                  Від першого запиту
                  <br />
                  до готових меблів
                </h2>
              </div>

              <p className={styles.processIntro}>
                Зрозумілий послідовний процес без готових шаблонів — кожне
                замовлення проходить шлях від вашої ідеї до встановлення.
              </p>
            </div>

            <ol className={styles.processTimeline}>
              {processSteps.map((step) => (
                <li key={step.number} className={styles.processStep}>
                  <div className={styles.processMarker}>
                    <span>{step.number}</span>
                  </div>

                  <div className={styles.processContent}>
                    <h3 className={styles.processStepTitle}>{step.title}</h3>

                    <p className={styles.processDescription}>
                      {step.description}
                    </p>
                  </div>
                </li>
              ))}
            </ol>

            <div className={styles.processAction}>
              <Link href="/contacts#lead-form" className={styles.processButton}>
                Обговорити проєкт
                <span aria-hidden="true">→</span>
              </Link>
            </div>
          </div>
        </section>

        <section className={styles.materials}>
          <div className="container">
            <div className={styles.materialsHeader}>
              <div>
                <p className={styles.materialsEyebrow}>
                  МАТЕРІАЛИ ТА ФУРНІТУРА
                </p>

                <h2 className={styles.materialsTitle}>
                  Підбираємо рішення
                  <br />
                  під конкретний проєкт
                </h2>
              </div>

              <div>
                <p className={styles.materialsIntro}>
                  Матеріали, кольори та механізми підбираються під конструкцію,
                  стиль, умови використання та бюджет майбутніх меблів.
                </p>

                <Link href="/materials" className={styles.materialsLink}>
                  Детальніше про матеріали
                  <span aria-hidden="true">→</span>
                </Link>
              </div>
            </div>

            <div className={styles.materialsGrid}>
              {materials.map((item) => (
                <article key={item.number} className={styles.materialCard}>
                  <div className={styles.materialTop}>
                    <span className={styles.materialNumber}>{item.number}</span>
                    <span className={styles.materialPlus} aria-hidden="true">
                      +
                    </span>
                  </div>

                  <div className={styles.materialContent}>
                    <h3 className={styles.materialTitle}>{item.title}</h3>

                    <p className={styles.materialDescription}>
                      {item.description}
                    </p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.about}>
          <div className="container">
            <div className={styles.aboutGrid}>
              <div>
                <p className={styles.aboutEyebrow}>ПРО 4HOME</p>

                <h2 className={styles.aboutTitle}>
                  Меблі, які починаються
                  <br />
                  з вашого простору
                </h2>
              </div>

              <div className={styles.aboutContent}>
                <p className={styles.aboutLead}>
                  4HOME — меблі на замовлення для квартир і будинків у Києві та
                  передмісті.
                </p>

                <p className={styles.aboutText}>
                  Кожен проєкт створюється індивідуально: від першого
                  обговорення та заміру до підбору матеріалів, виготовлення,
                  доставки й монтажу.
                </p>

                <p className={styles.aboutText}>
                  Ми не продаємо готові меблі зі складу. Конструкція, розміри,
                  наповнення та зовнішній вигляд підбираються під конкретне
                  приміщення і ваші побажання.
                </p>

                <div className={styles.aboutActions}>
                  <Link href="/about" className={styles.aboutLink}>
                    Детальніше про 4HOME
                    <span aria-hidden="true">→</span>
                  </Link>

                  <Link href="/contacts#lead-form" className={styles.aboutButton}>
                    Обговорити проєкт
                  </Link>
                </div>
              </div>
            </div>

            <div className={styles.aboutFacts}>
              {aboutFacts.map((fact) => (
                <div key={fact.number} className={styles.aboutFact}>
                  <span className={styles.aboutFactNumber}>{fact.number}</span>
                  <p className={styles.aboutFactText}>{fact.title}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.faq}>
          <div className="container">
            <div className={styles.faqGrid}>
              <div className={styles.faqHeader}>
                <p className={styles.faqEyebrow}>ПОШИРЕНІ ПИТАННЯ</p>

                <h2 className={styles.faqTitle}>
                  Відповіді перед
                  <br />
                  початком проєкту
                </h2>

                <p className={styles.faqIntro}>
                  Зібрали основні питання, які виникають перед замовленням
                  меблів.
                </p>
              </div>

              <FaqAccordion items={faqItems} />
            </div>
          </div>
        </section>

        <section className={styles.finalCta}>
          <div className="container">
            <div className={styles.finalCtaGrid}>
              <div className={styles.finalCtaMain}>
                <p className={styles.finalCtaEyebrow}>
                  ГОТОВІ ОБГОВОРИТИ ПРОЄКТ?
                </p>

                <h2 className={styles.finalCtaTitle}>
                  Розкажіть, які меблі
                  <br />
                  вам потрібні
                </h2>
              </div>

              <div className={styles.finalCtaContent}>
                <p className={styles.finalCtaText}>
                  Надішліть фото, приблизні розміри або коротко опишіть задачу.
                  Цього достатньо, щоб почати обговорення майбутнього проєкту.
                </p>

                <div className={styles.finalCtaActions}>
                  <Link href="/contacts#lead-form" className={styles.finalCtaPrimary}>
                    Розрахувати вартість
                    <span aria-hidden="true">→</span>
                  </Link>

                  <a
                    href={CONTACTS.phone.href}
                    className={styles.finalCtaSecondary}
                  >
                    Зателефонувати
                  </a>
                </div>
              </div>
            </div>

            <div className={styles.finalContacts}>
              <a
                href={CONTACTS.phone.href}
                className={styles.finalContactItem}
              >
                <span className={styles.finalContactLabel}>Телефон</span>
                <span className={styles.finalContactValue}>
                  {CONTACTS.phone.display}
                </span>
              </a>

              <a
                href={CONTACTS.email.href}
                className={styles.finalContactItem}
              >
                <span className={styles.finalContactLabel}>Email</span>
                <span className={styles.finalContactValue}>
                  {CONTACTS.email.display}
                </span>
              </a>

              <a
                href={CONTACTS.instagram.href}
                target="_blank"
                rel="noreferrer"
                className={styles.finalContactItem}
              >
                <span className={styles.finalContactLabel}>Instagram</span>
                <span className={styles.finalContactValue}>
                  {CONTACTS.instagram.label}
                </span>
              </a>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
